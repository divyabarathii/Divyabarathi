def fact(n):
  if n==0 or n==1:
    return 1
  else:
    return n*fact(n-1)
number=int(input("Enter number to find factorial:"))
result=fact(number)
print("The factorial of a {} is {}.".format(number,result))


1.1




def leap_year(year):
  if(year % 4 == 0 and year % 100 == 0):
    return True
  else:
    return False

year=int(input("Enter a year: "))

if leap_year(year):
  print("{} is a leap year.".format(year))
else:
  print("{} is not a leap year.".format(year))
  


1.2
